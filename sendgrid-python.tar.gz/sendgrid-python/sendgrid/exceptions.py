class SGServiceException(Exception):
    """
    Sendgrid service error
    """
    pass